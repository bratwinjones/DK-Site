# DK — Sauna & Hot-Tub Studio Website

Static, dependency-free site (HTML + CSS + vanilla JS). Mobile-first, accessible, fast.

## Preview

- **In Arena:** the live preview panel serves this folder automatically (static server on port 8090).
- **Locally:** open `index.html` in a browser, or serve the folder:
  `python3 -m http.server 8090` then visit `http://localhost:8090`.

## Files

```
dk-website/
├── index.html              # All content & sections
├── css/style.css           # Design system, layout, animations
├── js/main.js              # Nav, scrollspy, reveals, counters, lightbox
└── assets/img/
    ├── hero-sauna.jpg          # Hero background (1920w)
    ├── about-spa.jpg           # About section image
    ├── cta-golden-hour.jpg     # Mid-page CTA band background
    └── gallery/
        ├── thumbs/g01–g17.jpg  # Gallery grid images (800w, lazy-loaded)
        └── full/g01–g17.jpg    # Lightbox images (max 1600w)
```

All photography is real DK project work (Cape Town & Western Cape), except
`assets/img/services/hot-tub-installation.jpg`, which is a placeholder until a
real hot-tub photo is supplied (see the `HOT-TUB CARD IMAGE` comment in
`index.html`).

## Editing guide

### WhatsApp number
Displayed everywhere as **068 530 2223**; all links use the international
format: `https://wa.me/27685302223?text=...`.
To change it, search & replace `27685302223` (links) and `068 530 2223`
(displayed text) in `index.html`.

### Services
Each service is one `<article class="card">` block in `index.html`
(markered with the comment `SERVICE CARDS`). Edit the `<h3>`, `<p>` and the
inline SVG icon; copy an entire `<article>` to add another card. The grid
adjusts automatically (1 → 2 → 3 columns).

### Gallery
Each image is one `<figure>` in the `#galleryGrid` block. To use real photos:
1. Drop your files into `assets/img/gallery/thumbs/` and `.../full/`
   (keep the same file names), **or**
2. Edit the `src` (thumbnail), `data-full` (lightbox image) and
   `<figcaption>` / `alt` text of any `<figure>`.
The grid is responsive: 1 → 2 → 3 → 4 columns.

### About text & stats
Paragraphs live under the `ABOUT TEXT` comment. Stats animate from 0 to the
value of each `data-count` attribute.

### Colours & type
All tokens are CSS custom properties at the top of `css/style.css`
(`--gold`, `--paper`, `--dark`, `--wa`, fonts, radii, shadows).

### Business details
Footer hours / service area: edit `.footer-note` in `index.html`.
Facebook page link: edit the `footer-fb` anchor in `index.html`
(currently https://www.facebook.com/profile.php?id=61594843325324).

## Accessibility & performance notes

- Semantic landmarks, skip link, visible focus styles, ARIA on nav/lightbox.
- All images lazy-loaded (except hero, which is preloaded); descriptive alt text.
- Animations honour `prefers-reduced-motion`.
- No frameworks, no webfonts, no external requests — whole page ≈ 100 KB of
  code + only the images in view are downloaded.
